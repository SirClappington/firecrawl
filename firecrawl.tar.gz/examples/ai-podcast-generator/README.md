# Generate AI podcasts based on real time news 🎙️

This example crawls the web for interesting news stories then records a podcast with your own voice.

Here is a link to the repo:

[https://github.com/ericciarla/aginews-podcast](https://github.com/ericciarla/aginews-podcast)