# OpenAI Realtime API with Firecrawl

This project is a demo of the OpenAI Realtime API with Firecrawl integrated.

Here is a link to the Realtime console fork:

[https://github.com/nickscamara/firecrawl-openai-realtime](https://github.com/nickscamara/firecrawl-openai-realtime)