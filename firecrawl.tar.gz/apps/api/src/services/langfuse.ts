import { Langfuse } from "langfuse";

export const langfuse = new Langfuse();