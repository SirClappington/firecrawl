## CHANGELOG

## [0.1]

### Added

- [feat] Firecrawl rust sdk.
