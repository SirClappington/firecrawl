# AGI News ✨
AGI News is a daily AI newsletter that's completely sourced by autonomous AI agents. It is live at [https://www.aginews.io/](https://www.aginews.io/)

Here is a link to the repo:

[https://github.com/ericciarla/aginews](https://github.com/ericciarla/aginews)