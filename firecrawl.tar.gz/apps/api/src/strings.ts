export const errorNoResults =
  "No results found, please check the URL or contact us at help@mendable.ai to file a ticket.";

export const clientSideError = "client-side exception has occurred";
